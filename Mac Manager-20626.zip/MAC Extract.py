import re
import os

# Script-Ordner
base_dir = os.path.dirname(os.path.abspath(__file__))

# Dateien
input_file = os.path.join(base_dir, "auswertung.txt")
output_file = os.path.join(base_dir, "mac_adressen.txt")

# Nur echte MAC-Adressen erkennen
# Begrenzt durch Nicht-Buchstaben/Zahlen davor und danach
mac_pattern = re.compile(
    r'(?<![0-9A-Fa-f])'
    r'((?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2})'
    r'(?![0-9A-Fa-f])',
    re.IGNORECASE
)

def normalize_mac(mac):
    clean = re.sub(r'[:-]', '', mac).lower()
    return ':'.join(clean[i:i+2] for i in range(0, 12, 2))

try:
    found_macs = []

    with open(input_file, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            matches = mac_pattern.findall(line)

            for mac in matches:
                found_macs.append(normalize_mac(mac))

    # Duplikate entfernen
    unique_macs = sorted(set(found_macs))

    with open(output_file, "w", encoding="utf-8") as f:
        for mac in unique_macs:
            f.write(mac + "\n")

    print(f"Fertig.")
    print(f"{len(unique_macs)} eindeutige MAC-Adressen gefunden.")
    print("Gespeichert in mac_adressen.txt")

except Exception as e:
    print("FEHLER:")
    print(e)

input("Enter drücken zum Beenden...")