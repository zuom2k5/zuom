import re
import tkinter as tk
from tkinter import filedialog, messagebox
from datetime import datetime


# ==============================
# REGEX
# ==============================

MAC_REGEX = re.compile(r'\b(?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}\b')
URL_REGEX = re.compile(r'https?://[^\s]+', re.IGNORECASE)

DATE_PATTERNS = [
    re.compile(
        r'(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},\s+\d{4},\s+\d{1,2}:\d{2}\s*(am|pm)',
        re.IGNORECASE
    ),
    re.compile(r'Expires\s*➤?\s*(\d{2}\.\d{2}\.\d{4})', re.IGNORECASE),
    re.compile(r'\b\d{2}\.\d{2}\.\d{4}\b')
]


# ==============================
# KEYWORDS
# ==============================

DE_KEYWORDS = [
    "deutschland",
    "kinder",
    "allgemein",
    "filme",
    "UNTERHALTUNG",
    "ALLGEMEINES"
]

XXX_KEYWORDS = [
    "xxx",
    "adult",
    "adults"
]


# ==============================
# DATE PARSING
# ==============================

def parse_date(date_string):

    if not date_string or date_string == "Kein Datum gefunden":
        return datetime.min

    date_string = date_string.replace("Expires ➤", "").strip()

    formats = [
        "%B %d, %Y, %I:%M %p",
        "%d.%m.%Y"
    ]

    for fmt in formats:
        try:
            return datetime.strptime(date_string, fmt)
        except:
            continue

    return datetime.min


def find_date(lines, start, max_lookahead=5):

    for i in range(start + 1, min(start + max_lookahead, len(lines))):
        for pattern in DATE_PATTERNS:
            match = pattern.search(lines[i])
            if match:
                return match.group(0)

    return "Kein Datum gefunden"


# ==============================
# URL FILTER (ROBUST)
# ==============================

def extract_urls(lines):

    urls = set()

    blocked_patterns = [
        "m3u8",
        "m3u_plus",
        "m3u+",
        "plus.m3u"
    ]

    for line in lines:

        for url in URL_REGEX.findall(line):

            clean = url.lower()

            # IPTV / Playlist Müll
            if any(b in clean for b in blocked_patterns):
                continue

            # alles mit "+"
            if "+" in clean:
                continue

            # endet auf plus
            if clean.rstrip("/").endswith("plus"):
                continue

            urls.add(url.strip())

    return sorted(urls)


# ==============================
# SCAN LOGIC (FIXED DE + XXX)
# ==============================

def scan_file(filepath):

    with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
        lines = f.readlines()

    urls = extract_urls(lines)

    macs = {}
    mac_positions = []

    # MACs sammeln
    for i, line in enumerate(lines):
        for mac in MAC_REGEX.findall(line):
            mac_positions.append((i, mac.upper()))

    # Blockweise Verarbeitung
    for idx, (line_index, mac) in enumerate(mac_positions):

        if idx < len(mac_positions) - 1:
            end = mac_positions[idx + 1][0]
        else:
            end = len(lines)

        block = " ".join(lines[line_index:end]).lower()

        # DE Pflicht
        is_de = any(k in block for k in DE_KEYWORDS)
        if not is_de:
            continue

        # XXX gleiche Logik wie DE (im selben Block)
        is_xxx = any(k in block for k in XXX_KEYWORDS)

        if mac not in macs:
            macs[mac] = {
                "dates": [],
                "xxx": is_xxx
            }
        else:
            macs[mac]["xxx"] |= is_xxx

        date = find_date(lines, line_index)
        macs[mac]["dates"].append(date)

    return urls, macs


# ==============================
# OUTPUT
# ==============================

def save_output(urls, macs, base_file):

    out = base_file.rsplit(".", 1)[0] + "_DE_filtered.txt"

    sorted_macs = sorted(
        macs.items(),
        key=lambda x: min(
            parse_date(d)
            for d in x[1]["dates"] or ["Kein Datum gefunden"]
        )
    )

    with open(out, "w", encoding="utf-8") as f:

        # URLs
        f.write(f"Gefundene URLs: {len(urls)}\n\n")

        for u in urls:
            f.write(u + "\n")

        f.write("\n")

        # Stats
        f.write(f"Gefundene DE MACs: {len(macs)}\n\n")

        # MACS
        for mac, data in sorted_macs:

            label = mac + " [DE]"

            if data["xxx"]:
                label += " [XXX]"

            f.write(label + "\n")

            for d in sorted(data["dates"], key=parse_date):
                f.write(f" - {d}\n")

            f.write("\n")

    return out


# ==============================
# GUI
# ==============================

def choose_file():

    path = filedialog.askopenfilename(
        title="Datei auswählen",
        filetypes=[("Text", "*.txt"), ("Log", "*.log"), ("Alle", "*.*")]
    )

    if not path:
        return

    try:
        urls, macs = scan_file(path)

        if not macs:
            messagebox.showinfo("Info", "Keine DE-MACs gefunden.")
            return

        out = save_output(urls, macs, path)

        messagebox.showinfo("Fertig", out)

    except Exception as e:
        messagebox.showerror("Fehler", str(e))


# ==============================
# START
# ==============================

root = tk.Tk()
root.title("MAC Extract DE+XXX+URL")
root.geometry("420x180")
root.resizable(False, False)

tk.Label(
    root,
    text="MAC Extract DE+XXX+URL",
    font=("Arial", 14, "bold")
).pack(pady=15)

tk.Button(
    root,
    text="Datei auswählen",
    command=choose_file,
    width=25,
    height=2
).pack(pady=20)

root.mainloop()