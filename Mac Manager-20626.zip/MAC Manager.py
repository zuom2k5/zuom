import tkinter as tk
from tkinter import messagebox
import subprocess
import os
import sys

# ==========================================
# EINSTELLUNGEN: Hier deine Dateinamen eintragen
# ==========================================
SCRIPT_1 = "Auswertung Zusammenfassen.py"
SCRIPT_2 = "MAC Extract ALL+DE+URL.py"
SCRIPT_3 = "MAC Extract DE+XXX+URL.py"


def starte_skript(skript_name):
    """Startet das angegebene Python-Skript im Hintergrund."""
    # Prüfen, ob die Datei überhaupt existiert
    if not os.path.exists(skript_name):
        messagebox.showerror(
            "Fehler", 
            f"Die Datei '{skript_name}' wurde im aktuellen Ordner nicht gefunden!\n\n"
            f"Bitte überprüfe den Dateinamen oder lege diese GUI-Datei in denselben Ordner."
        )
        return
    
    try:
        # Ermittelt den aktuellen Python-Interpreter (funktioniert für Windows, Mac & Linux)
        python_executable = sys.executable
        
        # Startet das Skript als separaten Prozess, damit die GUI nicht einfriert
        subprocess.Popen([python_executable, skript_name])
        
    except Exception as e:
        messagebox.showerror("Fehler", f"Fehler beim Starten von {skript_name}:\n{e}")


# ==========================================
# GUI ERSTELLUNG (Tkinter)
# ==========================================
root = tk.Tk()
root.title("Skript-Manager")
root.geometry("450x300")
root.configure(bg="#2c3e50")  # Moderner, dunkler Hintergrund

# Stil für die Buttons definieren
button_style = {
    "font": ("Arial", 12, "bold"),
    "bg": "#3498db",          # Schönes Blau
    "fg": "white",            # Weiße Schrift
    "activebackground": "#2980b9",
    "activeforeground": "white",
    "width": 25,
    "height": 2,
    "bd": 0,                  # Kein hässlicher Rahmen
    "cursor": "hand2"         # Zeigefinger beim Drüberfahren
}

# Titel-Label
titel = tk.Label(
    root, 
    text="MAC Manager", 
    font=("Arial", 16, "bold"), 
    bg="#2c3e50", 
    fg="#ecf0f1"
)
titel.pack(pady=25)

# Button für Skript 1
btn1 = tk.Button(root, text=f"{SCRIPT_1}", **button_style,
                 command=lambda: starte_skript(SCRIPT_1))
btn1.pack(pady=8)

# Button für Skript 2
btn2 = tk.Button(root, text=f"{SCRIPT_2}", **button_style,
                 command=lambda: starte_skript(SCRIPT_2))
btn2.pack(pady=8)

# Button für Skript 3
btn3 = tk.Button(root, text=f"{SCRIPT_3}", **button_style,
                 command=lambda: starte_skript(SCRIPT_3))
btn3.pack(pady=8)

# Startet die GUI-Endlosschleife
root.mainloop()
