import re
import tkinter as tk
from tkinter import filedialog, messagebox
from datetime import datetime


MAC_REGEX = re.compile(r'\b(?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}\b')
URL_REGEX = re.compile(r'https?://[^\s]+', re.IGNORECASE)
TAG_REGEX = re.compile(r'\[[^\]]+\]')


def parse_date(date_string):

    if not date_string or date_string == "Kein Datum gefunden":
        return datetime.min

    date_string = date_string.replace("Expires ➤", "").strip()

    formats = [
        "%B %d, %Y, %I:%M %p",
        "%d.%m.%Y"
    ]

    for fmt in formats:
        try:
            return datetime.strptime(date_string, fmt)
        except:
            pass

    return datetime.min


# ==========================
# AUSWERTUNG PARSEN
# ==========================

def read_auswertung(filepath):

    urls = set()
    macs = {}

    with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
        lines = f.readlines()

    current_mac = None

    for line in lines:

        line = line.strip()
        if not line:
            continue

        # URLs
        for url in URL_REGEX.findall(line):
            urls.add(url)

        # MAC erkennen
        mac_match = MAC_REGEX.search(line)

        if mac_match:
            mac = mac_match.group(0)
            current_mac = mac

            tags = set(TAG_REGEX.findall(line))

            if mac not in macs:
                macs[mac] = {
                    "tags": tags,
                    "dates": []
                }
            else:
                macs[mac]["tags"].update(tags)

            continue

        # Datum (kommt direkt unter MAC)
        if current_mac and line.startswith("-"):
            date = line.replace("-", "").strip()
            macs[current_mac]["dates"].append(date)

    return urls, macs


# ==========================
# MERGE LOGIK
# ==========================

def merge_files(file1, file2):

    urls1, macs1 = read_auswertung(file1)
    urls2, macs2 = read_auswertung(file2)

    merged_urls = sorted(urls1.union(urls2))

    merged_macs = macs1.copy()

    for mac, data in macs2.items():

        if mac not in merged_macs:
            merged_macs[mac] = data
        else:
            merged_macs[mac]["tags"].update(data["tags"])
            merged_macs[mac]["dates"].extend(data["dates"])

    return merged_urls, merged_macs


# ==========================
# DATUM SORTIERUNG
# ==========================

def save_merged_file(urls, macs, base_file):

    output_file = base_file.rsplit(".", 1)[0] + "_komplett.txt"

    sorted_macs = sorted(
        macs.items(),
        key=lambda item: min(
            parse_date(d)
            for d in (item[1]["dates"] or ["Kein Datum gefunden"])
        )
    )

    total_macs = len(macs)
    total_tags = sum(1 for m in macs.values() if "[DE]" in m["tags"])

    with open(output_file, "w", encoding="utf-8") as f:

        # URLs
        f.write(f"Gefundene URLs: {len(urls)}\n\n")
        for url in urls:
            f.write(url + "\n")

        f.write("\n")

        # Stats
        f.write(f"Gefundene MAC-Adressen: {total_macs}\n")
        f.write(f"MACs mit [DE]: {total_tags}\n\n")

        # MACs
        for mac, data in sorted_macs:

            label = mac + " " + " ".join(sorted(data["tags"]))
            f.write(label + "\n")

            for d in sorted(data["dates"], key=parse_date):
                f.write(f" - {d}\n")

            f.write("\n")

    return output_file


# ==========================
# GUI
# ==========================

def choose_files():

    file1 = filedialog.askopenfilename(title="Datei 1 (Basis)")
    if not file1:
        return

    file2 = filedialog.askopenfilename(title="Datei 2 (Ergänzung)")
    if not file2:
        return

    try:
        urls, macs = merge_files(file1, file2)

        output = save_merged_file(urls, macs, file1)

        messagebox.showinfo("Fertig", output)

    except Exception as e:
        messagebox.showerror("Fehler", str(e))


root = tk.Tk()
root.title("Auswertungen Zusammenführen")
root.geometry("420x180")
root.resizable(False, False)

tk.Label(
    root,
    text="MAC Auswertungen Zusammenführen",
    font=("Arial", 14, "bold")
).pack(pady=15)

tk.Button(
    root,
    text="Dateien auswählen",
    command=choose_files,
    width=25,
    height=2
).pack(pady=20)

root.mainloop()