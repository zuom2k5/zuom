import re
import tkinter as tk
from tkinter import filedialog, messagebox
from collections import defaultdict
from datetime import datetime


# ==============================
# REGEX
# ==============================

MAC_REGEX = re.compile(
    r'\b(?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}\b'
)

URL_REGEX = re.compile(
    r'https?://[^\s\'"]+',
    re.IGNORECASE
)

DATE_PATTERNS = [
    # December 1, 2026, 5:13 pm
    re.compile(
        r'(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},\s+\d{4},\s+\d{1,2}:\d{2}\s*(am|pm)',
        re.IGNORECASE
    ),

    # Expires ➤ 01.02.2027
    re.compile(
        r'Expires\s*➤?\s*(\d{2}\.\d{2}\.\d{4})',
        re.IGNORECASE
    ),

    # 01.02.2027
    re.compile(
        r'\b\d{2}\.\d{2}\.\d{4}\b'
    )
]

DE_KEYWORDS = [
    "deutschland",
    "kinder",
    "allgemein",
    "filme",
    "UNTERHALTUNG",
    "ALLGEMEINES"
]


# ==============================
# DATUM SUCHEN
# ==============================

def find_date_nearby(
    lines,
    start_index,
    max_lookahead=5
):

    end_index = min(
        start_index + max_lookahead,
        len(lines)
    )

    for i in range(
        start_index + 1,
        end_index
    ):

        line = lines[i]

        for pattern in DATE_PATTERNS:

            match = pattern.search(line)

            if match:
                return match.group(0)

    return "Kein Datum gefunden"


# ==============================
# DE PRÜFUNG
# ==============================

def should_mark_de(
    lines,
    start,
    end
):

    text = " ".join(
        lines[start:end]
    ).lower()

    return any(
        keyword in text
        for keyword in DE_KEYWORDS
    )


# ==============================
# DATUM PARSEN
# ==============================

def parse_date(date_string):

    # Kein Datum zuerst
    if (
        not date_string
        or date_string == "Kein Datum gefunden"
    ):
        return datetime.min

    date_string = (
        date_string
        .replace("Expires ➤", "")
        .strip()
    )

    formats = [
        "%B %d, %Y, %I:%M %p",
        "%d.%m.%Y"
    ]

    for fmt in formats:

        try:
            return datetime.strptime(
                date_string,
                fmt
            )

        except:
            continue

    # Unbekannte Daten ebenfalls oben
    return datetime.min


# ==============================
# URLS EXTRAHIEREN
# ==============================

def extract_urls(lines):

    urls = set()

    for line in lines:

        found_urls = URL_REGEX.findall(
            line
        )

        for url in found_urls:

            clean_url = url.strip()

            # URLs mit m3u_plus ignorieren
            if clean_url.lower().endswith(
                "m3u_plus"
            ):
                continue

            urls.add(clean_url)

    return sorted(urls)


# ==============================
# DATEI SCANNEN
# ==============================

def scan_file(filepath):

    results = defaultdict(set)
    de_marked = set()

    with open(
        filepath,
        "r",
        encoding="utf-8",
        errors="ignore"
    ) as file:

        lines = file.readlines()

    # URLs sammeln
    urls = extract_urls(lines)

    mac_positions = []

    # Alle MACs sammeln
    for i, line in enumerate(lines):

        macs = MAC_REGEX.findall(
            line
        )

        for mac in macs:

            mac_positions.append(
                (
                    i,
                    mac.upper()
                )
            )

    # Verarbeitung
    for idx, (
        line_index,
        mac
    ) in enumerate(mac_positions):

        # Datum suchen
        found_date = (
            find_date_nearby(
                lines,
                line_index
            )
        )

        results[mac].add(
            found_date
        )

        # Letzte MAC beachten
        if idx < (
            len(mac_positions) - 1
        ):

            next_index = (
                mac_positions[
                    idx + 1
                ][0]
            )

        else:
            next_index = len(lines)

        # DE markieren
        if should_mark_de(
            lines,
            line_index,
            next_index
        ):

            de_marked.add(mac)

    return (
        results,
        de_marked,
        urls
    )


# ==============================
# DATEI SPEICHERN
# ==============================

def save_results(
    results,
    de_marked,
    urls,
    source_file
):

    output_file = (
        source_file.rsplit(
            ".",
            1
        )[0]
        + "_auswertung.txt"
    )

    # Nach Datum sortieren
    sorted_results = sorted(
        results.items(),
        key=lambda item: min(
            parse_date(date)
            for date in item[1]
        )
    )

    with open(
        output_file,
        "w",
        encoding="utf-8"
    ) as f:

        # URLS
        f.write(
            f"Gefundene URLs: "
            f"{len(urls)}\n\n"
        )

        for url in urls:
            f.write(
                url + "\n"
            )

        f.write("\n")

        # Statistik
        f.write(
            f"Gefundene "
            f"MAC-Adressen: "
            f"{len(results)}\n"
        )

        f.write(
            f"Davon DE "
            f"gekennzeichnet: "
            f"{len(de_marked)}\n\n"
        )

        # Ergebnisse
        for mac, dates in sorted_results:

            label = mac

            if mac in de_marked:
                label += " [DE]"

            f.write(
                label + "\n"
            )

            # Datumswerte sortieren
            sorted_dates = sorted(
                dates,
                key=parse_date
            )

            for date in sorted_dates:

                f.write(
                    f" - {date}\n"
                )

            f.write("\n")

    return output_file


# ==============================
# DATEI WÄHLEN
# ==============================

def choose_file():

    filepath = (
        filedialog.askopenfilename(
            title="Datei auswählen",
            filetypes=[
                (
                    "Textdateien",
                    "*.txt"
                ),
                (
                    "Log-Dateien",
                    "*.log"
                ),
                (
                    "Alle Dateien",
                    "*.*"
                )
            ]
        )
    )

    if not filepath:
        return

    try:

        (
            results,
            de_marked,
            urls
        ) = scan_file(
            filepath
        )

        if not results:

            messagebox.showinfo(
                "Info",
                "Keine "
                "MAC-Adressen "
                "gefunden."
            )

            return

        output = save_results(
            results,
            de_marked,
            urls,
            filepath
        )

        messagebox.showinfo(
            "Fertig",
            f"Datei gespeichert:\n\n"
            f"{output}"
        )

    except Exception as e:

        messagebox.showerror(
            "Fehler",
            str(e)
        )


# ==============================
# GUI
# ==============================

root = tk.Tk()

root.title(
    "MAC Extract All+DE+URL"
)

root.geometry(
    "420x180"
)

root.resizable(
    False,
    False
)

title_label = tk.Label(
    root,
    text="MAC Extract All+DE+URL",
    font=(
        "Arial",
        14,
        "bold"
    )
)

title_label.pack(
    pady=15
)

scan_button = tk.Button(
    root,
    text="Datei auswählen",
    command=choose_file,
    width=24,
    height=2
)

scan_button.pack(
    pady=15
)

root.mainloop()